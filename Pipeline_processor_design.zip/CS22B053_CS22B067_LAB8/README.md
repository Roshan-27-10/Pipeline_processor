Team Members:-
Roshan Manimaran: CS22B053
Anshuman Jindal: CS22B067

main.cpp should be present in CS22B053_CS22B067_LAB8 folder

The input files must be in directory "input", named as in the probelm statement. The required output files will be created in
the directory "output", also following the structure and the naming convention as outlined in the problem statement pdf

Open the temrinal in the folder CS22B053_CS22B067_LAB8
On the command line:

# To compile:-
g++ main.cpp -o Lab8

# To run:-
./Lab8

# See the required outputs in the "output" folder